// I was born in 1980

//I was born in 1980

//Summing Numbers! 
//num 1 is: 10
//num 2 is: 20
//30